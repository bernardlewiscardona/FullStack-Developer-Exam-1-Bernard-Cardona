import React from "react";

export default function content(props){
    let flightdate = new Date (props.data.date_local)
    let year = flightdate.getFullYear()
    return(
            <section className="content">
                <img className="content-image" src={props.data.links.patch.small} alt="photo.png" />
                <div className="content-details">
                    <h3>Flight Number: {props.data.flight_number} Mission Name: {props.data.name} ({year})</h3>
                    <p>{!props.data.details ? `Details: None` :`Details: ${props.data.details}` }.</p>
                </div>
            </section>
    )
}