import React from "react";
export default function header(){
    return(
        <div className="header">
            <input type="text" placeholder="Enter Keywords" name="search" />
        </div>
    )
}