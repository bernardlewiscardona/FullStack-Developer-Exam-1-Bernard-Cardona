import React from 'react'
import { useState, useEffect } from 'react'
import Search from './components/header'
import Content from './components/content'
import './App.css'

function App() {

  const [data,setData] = useState([])
  useEffect(() => {
    fetch(`https://api.spacexdata.com/v4/launches/`)
      .then(response => response.json())
      .then((item) => {
        setData(item);
        console.log(data)
      })
      .catch((e) => {
        console.error(`An error occurred: ${e}`)
      });
  }, []);
  
  const flights = data.map((flight) => {
    return(
      <Content key={flight.id} data={flight}/>
    )
  })
  return (
    <div className="App">
      <Search/>
      {flights}
    </div>
  )
}

export default App
